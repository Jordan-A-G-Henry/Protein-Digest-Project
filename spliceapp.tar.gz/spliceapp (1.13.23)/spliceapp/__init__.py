# -*- coding: utf-8 -*-
"""The spliceapp package"""
