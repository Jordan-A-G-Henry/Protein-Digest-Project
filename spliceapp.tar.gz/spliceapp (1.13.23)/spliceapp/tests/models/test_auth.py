# -*- coding: utf-8 -*-
"""Test suite for the TG app's models"""
from __future__ import unicode_literals
from nose.tools import eq_

from spliceapp import model
from spliceapp.tests.models import ModelTest


