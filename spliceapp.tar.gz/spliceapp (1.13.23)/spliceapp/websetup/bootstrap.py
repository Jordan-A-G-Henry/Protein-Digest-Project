# -*- coding: utf-8 -*-
"""Setup the spliceapp application"""
from __future__ import print_function, unicode_literals
from spliceapp import model


def bootstrap(command, conf, vars):
    """Place any commands to setup spliceapp here"""

    # <websetup.bootstrap.before.auth

    # <websetup.bootstrap.after.auth>
