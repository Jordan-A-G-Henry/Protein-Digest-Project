# -*- coding: utf-8 -*-
"""Setup the spliceapp application"""
from __future__ import print_function

from tg import config


def setup_schema(command, conf, vars):
    """Place any commands to setup spliceapp here"""
